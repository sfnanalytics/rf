Need to install PIP and Python to use this script 

Type "python" into a Command Prompt window to install Python

Installing PIP On Windows
Step 1: Download PIP get-pip.py
Before installing PIP, download the get-pip.py file: get-pip.py on pypa.io.

Download the file to the desired folder in Windows. You can save the file to any location, but remember the path so you can use it later.

Step 2: Launch Windows Command Line
PIP is a command-line program. When you install PIP, the PIP command is added to your system.

To launch the Command Prompt window:

Press Windows Key + X.
Click Run.
Type in cmd.exe and hit enter.
Alternatively, type cmd in the Windows search bar and click the “Command Prompt” icon.

Both options open the Command Prompt window. However, note that you may need to run the Command Prompt “As Administrator.” If you get an error at any point stating that you don’t have the necessary permissions to perform a task, you will need to open the app as admin.

To run the Command Prompt window “As Administrator,” right-click “Command Prompt” and then select the “Run as…” option.

Step 3: Installing PIP on Windows
Open the Command Prompt if it isn’t already open. Use the cd command followed by a folder name to navigate to the location of the get-pip.py file. This is the folder you previously used as the download location.

To install PIP type in the following:

python get-pip.py
PIP installation should start. If the file isn’t found, double-check the path to the folder where you saved the file.

You can view the contents of your current directory using the following command:

dir
The dir command returns a full listing of the contents of a directory.